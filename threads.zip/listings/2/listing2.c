#include <unistd.h>
#include <stdio.h>

int main(void)
{
	/* fork возвращает тип pid_t */
	pid_t p = 0; 
	
	p = fork();
	printf("fork returned %d\n", p);
	
	/* ждет 2 секунды и завершается */
	sleep(2);
	
	return 0;
}
