#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

void* Dinner(void* arg);

static sem_t threadsQueue;
static pthread_mutex_t forks[5] = PTHREAD_MUTEX_INITIALIZER;

int main()
{
	int i, result;
	pthread_t philosophers[5];
	sem_init(&threadsQueue, 0, 0);

	for(i = 0; i < 5; i++)
	{
		result = pthread_create(&philosophers[i], NULL, &Dinner, &i);
		if(result)
		{
			perror("Philosopher understood the meaning of life and died.\n");
			return EXIT_FAILURE;
		}
		sem_wait(&threadsQueue);
	}
	
	for(i = 0; i < 5; i++)
	{
		result = pthread_join(philosophers[i], NULL);
		if(result)
		{
			perror("Philospher was poisoned.\n");
			return EXIT_FAILURE;
		}
		printf("Philosopher %d went away.\n", i + 1);
	}
	
	return EXIT_SUCCESS;
}

void* Dinner(void* arg)
{
	int id, left, right;
	id = *(int*)arg;
	sem_post(&threadsQueue);
	left = (id + 1) % 5;
	right = id % 5;
	
	pthread_mutex_lock(&forks[left]);
	printf("Philosopher %d took left fork.\n", id + 1);
	sleep(2);
	pthread_mutex_lock(&forks[right]);
	printf("Philosopher %d took right fork.\n", id + 1);
	sleep(5);
	pthread_mutex_unlock(&forks[right]);
	pthread_mutex_unlock(&forks[left]);
	printf("Philosopher %d ate enough.\n", id + 1);
	return NULL;
}
