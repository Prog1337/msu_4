#include <stdio.h>
#include <math.h>

#define n 101

int main(void)
{
	FILE *fout = NULL;
	fout = fopen("pointsSurface.txt", "w");
	double x[n], y[n];
	for(int i = 0; i < n; i++)
	{
		x[i] = -5 + i / 10.;
		y[i] = -5 + i / 10.;
	}
	
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
			fprintf(fout, "%lg %lg %lg\n", x[i], y[j], sin(x[i] * y[j]) );
		fprintf(fout, " \n");
	}
	
	return 0;
}
