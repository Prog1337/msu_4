#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

void* RunInput(void * arg);
void* RunInvert(void* arg);

static char line[256];
static bool isFinished = false;
static sem_t inputReady;
static sem_t invertReady;

int main()
{
	pthread_t inputThread, invertThread;
	int res;
	
	sem_init(&inputReady, 0, 0);
	sem_init(&invertReady, 0, 1);
	
	res = pthread_create(&inputThread, NULL, &RunInput, NULL);
	if(res != 0)
	{
		perror("Can not create the first thread\n");
		exit(1);
	}
	
	res = pthread_create(&invertThread, NULL, &RunInvert, NULL);
	if(res != 0)
	{
		perror("Can not create the second thread\n");
		exit(1);
	}
	
	pthread_join(inputThread, NULL);
	pthread_join(invertThread, NULL);
	
	sem_destroy(&inputReady);
	sem_destroy(&invertReady);
	
	return EXIT_SUCCESS;
}

void* RunInput(void*)
{
	int l;
	while(true)
	{
		sem_wait(&invertReady);
		printf("Thread 1: Input a line (empty for exit):\n");
		fgets(line, 255, stdin);
		
		l = strlen(line);
		if(l > 0 && line[l - 1] == '\n')
		{
			line[l - 1] = 0;
			--l;
		}
		if(l > 0 && line[l - 1] == '\r')
		{
			line[l - 1] = 0;
			--l;
		}
		
		if(l == 0)
		{
			isFinished = true;
		}
		
		sem_post(&inputReady);
		if(isFinished)
		{
			break;
		}
	}
	
	return NULL;
}

void* RunInvert(void*)
{
	int i, l;
	while(true)
	{
		sem_wait(&inputReady);
		
		l = strlen(line);
		for(i = 0; i < l/2; ++i)
		{
			char tmp = line[i];
			line[i] = line[l - i - 1];
			line[l - i - 1] = tmp;
		}
		
		printf("Thread 2: Inverted line:\n%s\n", line);
		
		sem_post(&invertReady);
		
		if(isFinished)
		{
			break;
		}
	}
	
	return NULL;
}

