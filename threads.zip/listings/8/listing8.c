#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

void sighandler(int sig)
{
	printf("In signal handler for signal %d\n", sig);
	
	/* wait - это основное для потверждения SIGCHLD */
	wait(0);
}

int main(void)
{
	int i = 10;

	/*				 			ИЛИ 		
	 * sigset(SIGCHLD, &sighandler) до создания зомби (перед if)
	 * sleep(60) после создания зомби						   	*/
	 
	if(!fork())
	{
		sleep(10);
		/* потомок */
		_exit(i);
	}
	
	sleep(5);
	
	/* установить обработчик сигнала к SIGCHLD */
	sigset(SIGCHLD, &sighandler);
	
	sleep(20);
		
	return 0;
}


