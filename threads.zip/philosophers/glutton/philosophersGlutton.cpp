#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/times.h>
#include <pthread.h>
#include <semaphore.h>

#define PEOPLE_COUNT 5
#define HUNGER_LEVEL 3
#define TRIES_NUMBER 3

void* Gluttony(void* arg);
void* Dinner(void* arg);

static sem_t wink, threadsQueue;
static pthread_mutex_t forks[PEOPLE_COUNT] = PTHREAD_MUTEX_INITIALIZER;


int main()
{
	int i, id, result, glutton;
	pthread_t philosophers[PEOPLE_COUNT];
	sem_init(&threadsQueue, 0, 0);
	sem_init(&wink, 0, 0);
	srand(time(NULL));
	glutton = rand() % PEOPLE_COUNT;
	
	for(i = 0; i < PEOPLE_COUNT; i++)
	{
		id = i + 1;
		if(i == glutton || i == (glutton + 2) % PEOPLE_COUNT) 
			result = pthread_create(&philosophers[i], NULL, &Gluttony, &id);
		else 
			result = pthread_create(&philosophers[i], NULL, &Dinner, &id);
		if(result)
		{
			perror("Philosopher understood the meaning of life and died.\n");
			return EXIT_FAILURE;
		}
		sem_wait(&threadsQueue);
	}
	
	sem_wait(&wink);

	result = pthread_join(philosophers[(glutton + 1) % PEOPLE_COUNT], NULL);
	if(result)
	{
		perror("Philospher was poisoned.\n");
		return EXIT_FAILURE;
	}
	printf("Gluttons \"ate\" philosopher %d.\n", (glutton + 1) % PEOPLE_COUNT + 1);
	
	return EXIT_SUCCESS;
}

void* Gluttony(void* arg)
{
	int id, left, right, portion;
	id = *(int*)arg;
	sem_post(&threadsQueue);
	portion = 0;
	left = id % PEOPLE_COUNT;
	right = (id - 1) % PEOPLE_COUNT;
	
	while(true)
	{
		pthread_mutex_lock(&forks[left]);
		printf("Glutton %d took %d fork.\n", id, left + 1);
		pthread_mutex_lock(&forks[right]);
		printf("Glutton %d took %d fork.\n", id, right + 1);
		sem_post(&wink);
		++portion;
		sleep(3);
		printf("Glutton %d ate %d portions.\n", id, portion);
		sem_wait(&wink);
		pthread_mutex_unlock(&forks[right]);
		printf("Glutton %d put down %d fork.\n", id, right + 1);
		pthread_mutex_unlock(&forks[left]);
		printf("Glutton %d put down %d fork.\n", id, left + 1);
		sleep(2);
	}
	
	return NULL;
}

void* Dinner(void* arg)
{
	int i, id, left, right, temp, hunger, portion;
	bool isCaptured;
	id = *(int*)arg;
	sem_post(&threadsQueue);
	portion = 0;
	hunger = 0;
	left = id % PEOPLE_COUNT;
	right = (id - 1) % PEOPLE_COUNT;

	while(true)
	{
		pthread_mutex_lock(&forks[left]);
		printf("Philosopher %d took %d fork.\n", id, left + 1);
		isCaptured = false;
		sleep(2);
		for(i = 0; i < TRIES_NUMBER; i++)
		{
			if(pthread_mutex_trylock(&forks[right]) == 0)
			{
				isCaptured = true;
				break;
			}
			else sleep(1);
		}
		if(isCaptured)
		{
			++portion;
			hunger = 0;
			printf("Philosopher %d took %d fork.\n", id, right + 1);
			sleep(5);
			printf("Philosopher %d ate %d portions.\n", id, portion);
			pthread_mutex_unlock(&forks[right]);
			printf("Philosopher %d put down %d fork.\n", id, right + 1);
			pthread_mutex_unlock(&forks[left]);
			printf("Philosopher %d put down %d fork.\n", id, left + 1);
		}
		else
		{
			++hunger;
			pthread_mutex_unlock(&forks[left]);
			printf("Philosopher %d put down %d fork (hunger level : %d).\n", id, left + 1, hunger);
			temp = left;
			left = right;
			right = temp;
			if(hunger == HUNGER_LEVEL) break;
		}
		sleep(3);
	}
	
	return NULL;
}
