#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *tFunc(void *arg)
{
	/* static означает, что у нас одна и та же переменная и память, 
	 * то есть, фактически, новая переменная не создается
	 * Замечание: после завершения функции память не уничтожится;
	 * без static память выделялась бы при каждом вызове функции 
	 * и уничтожалась бы при завершении функции		*/
	static int ret = 27;
	
	printf("Привет из потока\n");
	return &ret;
}

int main(void)
{
	pthread_t tchild;
	void *status;
	pthread_create(&tchild, NULL, &tFunc, NULL);
	
	/* в адрес переменной status копируем адрес переменной ret */
	pthread_join(tchild, &status);
	
	printf("%d\n", *(int*)status);
	return 0;
}
