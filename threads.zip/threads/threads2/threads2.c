#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <errno.h>
#include <semaphore.h>
#include <unistd.h>
#define n 4

/* глобальная переменная sem типа семафор;
 семафор - это целочисленная беззнаковая переменная,
 предназначенная для межпоточного взаимодействия	
 отличается от других типов данных в обработке программы (процесса) потока диспетчером;
 есть специальные функции работы с этими переменными, 
 состоящие в проверке состояния и изменении этой переменной,
 в которых между проверкой и изменением поток не прерывается	*/
sem_t sem;

void *thread_func(void *arg)
{
	int i;
	int loc_id;
	
	sleep(6);
		
	loc_id = *(int *)arg;
	
	/* увеличивает значение семафора на единицу */
	sem_post(&sem);
	
	for(i = 0; i < 5; i++)
	{
		printf("Thread %d is running i = %d\n", loc_id, i);
		sleep(1);
	}
	
	return NULL;
}

int main(void)
{
	int id, result;
	pthread_t threadm[n];
	
	/* инициализация семафора 
	  1 аргумент - адрес переменной типа семафор, 
	  2 аргумент - если 0, то разделяется между потоками процесса, если не ноль, то между процессами
	  3 аргумент - значение, которым инициализируется семафор	*/
	sem_init(&sem, 0, 0);
	
	for(id = 1; id < n + 1; id++)
	{
		result = pthread_create(&threadm[id - 1], NULL, thread_func, &id);
		if(result != 0)
		{
			printf("Creating the %d thread failed\n", id);
			return EXIT_FAILURE;
		}
		else printf("%d thread creating\n", id);
		
		/* здесь нужна для того, чтобы id успел инкрементироваться;
		  проверяется переменная sem,
		  если положительна, значение уменьшается на единице;
		  если нулевая, соответствующий поток останавливается до момента, 
		  пока семафор не станет положительным		*/
		sem_wait(&sem);
	}
	
	for(id = 1; id < n + 1; id++)
	{
		result = pthread_join(threadm[id - 1], NULL);
		if(result != 0)
		{
			printf("Joining the %d thread failed", id);
			return EXIT_FAILURE;
		}
		else printf("%d thread joining\n", id);
	}
		
	/* уничтожаем семафор (больше семафор семафором не является) */
	sem_destroy(&sem);
	
	printf("Done\n");
	
	return EXIT_SUCCESS;
}
