#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define SLEEP 3
#define RANDOM 2
#define FIXED_UPDATE 3
#define READERS_BOOKS 7
#define READERS_COUNT 5
#define WRITERS_BOOKS 7
#define WRITERS_COUNT 5

void Stats();
void *Reader(void *arg);
void *Writer(void *arg);
void *ChangePriority(void *arg);

static sem_t readersDoor, writersDoor, threadsQueue;
static pthread_mutex_t library = PTHREAD_MUTEX_INITIALIZER;

static int left = 0, priorityMode = -1, currentCount = 0, waitingReader = 0, waitingWriter = 0, readBooks[READERS_COUNT] = {0}, writtenBooks[WRITERS_COUNT] = {0};
// -1 - писатели, 1 - читатели

int main()
{
    int i, id;
    left = READERS_COUNT + WRITERS_COUNT;
    srand(times(NULL));
    pthread_t readers[READERS_COUNT], writers[WRITERS_COUNT], priorityThread;
    sem_init(&readersDoor, 0, 0);
    sem_init(&writersDoor, 0, 0);
    sem_init(&threadsQueue, 0, 0);

    pthread_create(&priorityThread, nullptr, &ChangePriority, nullptr);
    for (i = 0; i < READERS_COUNT; i++)
    {
        id = i + 1;
        readBooks[i] = rand() % READERS_BOOKS + 2;
        pthread_create(&readers[i], nullptr, &Reader, &id);
        sem_wait(&threadsQueue);
    }
    for (i = 0; i < WRITERS_COUNT; i++)
    {
        id = i + 1;
        writtenBooks[i] = rand() % WRITERS_BOOKS + 2;
        pthread_create(&writers[i], nullptr, &Writer, &id);
        sem_wait(&threadsQueue);
    }

    pthread_join(priorityThread, nullptr);
    for (i = 0; i < READERS_COUNT; i++)
    {
        pthread_join(readers[i], nullptr);
    }
    for (i = 0; i < WRITERS_COUNT; i++)
    {
        pthread_join(writers[i], nullptr);
    }

    Stats();

    return EXIT_SUCCESS;
}

void *Reader(void *arg)
{
    int id = *(int *)arg, book = 0;
    bool isWaited = false;
    sem_post(&threadsQueue);

    while (1)
    {
        pthread_mutex_lock(&library);
        if (book == readBooks[id - 1])
        {
            printf("Reader %d read %d books.\n", id, book);
            --left;
            break;
        }
        if (currentCount >= 0 && ((!waitingWriter && priorityMode == -1) || priorityMode == 1))
        {
            ++currentCount;
            ++book;
            if (currentCount == READERS_COUNT)
                printf("Reader %d (the last) entered the library.\t current count : %d\t read books[%d] : %d\n", id, currentCount, id, book);
            else
                printf("Reader %d entered the library.\t\t\t current count : %d\t read books[%d] : %d\n", id, currentCount, id, book);
            if (isWaited)
            {
                sem_post(&readersDoor);
                isWaited = false;
            }
            pthread_mutex_unlock(&library);
        }
        else
        {
            printf("Reader %d is waiting...\n", id);
            isWaited = true;
            ++waitingReader;
            pthread_mutex_unlock(&library);
            sem_wait(&readersDoor);
            pthread_mutex_lock(&library);
            --waitingReader;
            pthread_mutex_unlock(&library);
            sleep(rand() % RANDOM);
            continue;
        }
        sleep(SLEEP * 2);
        pthread_mutex_lock(&library);
        if (--currentCount == 0)
        {
            printf("Reader %d (the last) left the library.\t\t current count : %d\n", id, currentCount);
            sem_post(&writersDoor);
        }
        else
            printf("Reader %d left the library.\t\t\t current count : %d\n", id, currentCount);
        pthread_mutex_unlock(&library);
        sleep(rand() % READERS_COUNT + SLEEP);
    }
    pthread_mutex_unlock(&library);

    return nullptr;
}

void *Writer(void *arg)
{
    int id = *(int *)arg, book = 0;
    sem_post(&threadsQueue);

    while (1)
    {
        pthread_mutex_lock(&library);
        if (book == writtenBooks[id - 1])
        {
            printf("Writer %d wrote %d books.\n", id, book);
            --left;
            break;
        }
        if (currentCount == 0)
        {
            currentCount = -1;
            ++book;
            printf("Writer %d entered the library.\t\t\t current count : %d\t written books[%d] : %d\n", id, currentCount, id, book);
            pthread_mutex_unlock(&library);
        }
        else
        {
            printf("Writer %d is waiting...\n", id);
            ++waitingWriter;
            pthread_mutex_unlock(&library);
            sem_wait(&writersDoor);
            pthread_mutex_lock(&library);
            --waitingWriter;
            pthread_mutex_unlock(&library);
            sleep(rand() % (RANDOM));
            continue;
        }
        sleep(SLEEP / 2 + 1);
        pthread_mutex_lock(&library);
        currentCount = 0;
        printf("Writer %d left the library.\t\t\t current count : %d\n", id, currentCount);
        if (priorityMode == 1)
        {
            sem_post(&readersDoor);
            sem_post(&writersDoor);
        }
        else
        {
            if (!waitingWriter)
                sem_post(&readersDoor);
            else
                sem_post(&writersDoor);
        }
        pthread_mutex_unlock(&library);
        sleep(rand() % WRITERS_COUNT + SLEEP / 2);
    }
    pthread_mutex_unlock(&library);

    return nullptr;
}

void *ChangePriority(void *arg)
{
    int temp = 0, tempReader = 0;
    pthread_mutex_lock(&library);
    printf("\t\t\tPRIORITY MODE : READERS\n\t\t\tWAITING READERS : %d\n\t\t\tWAITING WRITERS : %d\n", waitingReader, waitingWriter);
    pthread_mutex_unlock(&library);
    while (left)
    {
        pthread_mutex_lock(&library);
        temp = priorityMode;

        if ((waitingReader > waitingWriter && waitingWriter != WRITERS_COUNT) ||
            (temp == 1 && tempReader))
            priorityMode = 1;
        else if (waitingWriter >= waitingReader && waitingReader != READERS_COUNT)
            priorityMode = -1;
        else
            priorityMode = -priorityMode;
        if (temp != priorityMode)
        {
            if (priorityMode == 1)
                printf("\n\t\t\tPRIORITY MODE : READERS\n\t\t\tWAITING READERS : %d\n\t\t\tWAITING WRITERS : %d\n", waitingReader, waitingWriter);
            if (priorityMode == -1)
                printf("\n\t\t\tPRIORITY MODE : WRITERS\n\t\t\tWAITING READERS : %d\n\t\t\tWAITING WRITERS : %d\n", waitingReader, waitingWriter);
        }
        tempReader = waitingReader;
        pthread_mutex_unlock(&library);
        sleep(FIXED_UPDATE);
    }

    return nullptr;
}

void Stats()
{
    int i;
    printf("\n\t Stats\n");
    printf("\tReaders\n");
    for (i = 0; i < READERS_COUNT; i++)
    {
        printf("Reader %d read %d books.\n", i + 1, readBooks[i]);
    }
    printf("\tWriters\n");
    for (i = 0; i < READERS_COUNT; i++)
    {
        printf("Writer %d wrote %d books.\n", i + 1, writtenBooks[i]);
    }
    return;
}