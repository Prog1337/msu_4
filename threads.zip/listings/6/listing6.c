#include <unistd.h>
#include <stdio.h>

int main(void)
{
	int i;
	
	if(fork())
	{
		/* родитель */
		sleep(2);
		
		/* окончание процесса, где бы мы не находились;
		 отличие от return: return заканчивает функции, 
		 а _exit процесс */
		_exit(0);
	}
	
	/* потомок выводит на экран своего предка 5 раз */
	for(i = 0; i < 5; i++)
	{
		printf("My parent is %d\n", getppid());
		sleep(1);
	}	
	
	return 0;
}
