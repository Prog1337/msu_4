#include <unistd.h>
#include <stdio.h>

int main(void)
{
	/* создается переменная процессИдентификатор_тип */
	pid_t p;
	
	/* функция getpid, запущенная в процессе, возвращает его (процесса)идентификатор */
	printf("Original program, pid = %d\n", getpid());
	
	/* создается новый процесс и сохраняется в переменной */
	p = fork(); 
	
	/* если p = 0, это означает, что находимся в потомке */
	if(p == 0)
	{
		/* функция getppid возвращает идентификатор предка */
		printf("In child process, pid = %d, ppid = %d\n", getpid(), getppid());
	}
	/* иначе находимся в предке */
	else
	{
		printf("In parent, pid = %d, fork returned = %d\n", getpid(), p);
		
		/* ждет две секунды и все заканчивается */
		sleep(2); 
	}
	
	return 0;
}
