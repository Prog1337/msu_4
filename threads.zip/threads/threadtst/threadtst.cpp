#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/times.h>

void* run(void* arg);

static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int main()
{
	pthread_t thread1, thread2;
	int num1 = 1;
	int num2 = 2;
	int res = 0;
	
	srand(times(NULL));
	
	res = pthread_create(&thread1, NULL, &run, &num1);
	if(res != 0)
	{
		perror("Can not create thread 1\n");
		exit(1);
	}
	pthread_mutex_lock(&mutex);
	printf("Thread 1 is created\n");
	pthread_mutex_unlock(&mutex);
	
	res = pthread_create(&thread2, NULL, &run, &num2);
	if(res != 0)
	{
		perror("Can not create thread 2\n");
		exit(1);
	}
	pthread_mutex_lock(&mutex);
	printf("Thread 2 is created\n");
	pthread_mutex_unlock(&mutex);
	
	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);
	
	pthread_mutex_destroy(&mutex);
	
	return 0;
}

void* run(void* arg)
{
	int i;
	int num = *((int *) arg);
	
	for(i = 0; i < 10; i++)
	{
		int r = rand();
		r %= 3;
		
		pthread_mutex_lock(&mutex);
		printf("Thread %d.\n", num);
		pthread_mutex_unlock(&mutex);
		
		sched_yield();
		sleep(r);
	}
	
	return NULL;
}
