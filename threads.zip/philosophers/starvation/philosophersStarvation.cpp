#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/times.h>
#include <pthread.h>
#include <semaphore.h>

#define PEOPLE_COUNT 5
#define HUNGER_LEVEL 3
#define TRIES_NUMBER 3
#define RANDOM 5

void* Dinner(void* arg);
void Stats();

int hunger[PEOPLE_COUNT] = {0};

static sem_t threadsQueue;
static pthread_mutex_t forks[PEOPLE_COUNT] = PTHREAD_MUTEX_INITIALIZER;


int main()
{
	int i, result;
	pthread_t philosophers[PEOPLE_COUNT];
	sem_init(&threadsQueue, 0, 0);
	srand(time(NULL));
	
	printf("\tThe Start Of The Dinner\n");
	for(i = 1; i < PEOPLE_COUNT + 1; i++)
	{
		result = pthread_create(&philosophers[i - 1], NULL, &Dinner, &i);
		if(result)
		{
			perror("Philosopher understood the meaning of life and died.\n");
			return EXIT_FAILURE;
		}
		sem_wait(&threadsQueue);
	}
	
	sleep(RANDOM * PEOPLE_COUNT * TRIES_NUMBER * HUNGER_LEVEL / 2);
	
	printf("\n");
	printf("\tThe End Of The Dinner\n");
	for(i = 0; i < PEOPLE_COUNT; i++)
	{
		result = pthread_join(philosophers[i], NULL);
		if(result)
		{
			perror("Philospher was poisoned.\n");
			return EXIT_FAILURE;
		}
		if(hunger[i] == HUNGER_LEVEL)
			printf("Philosopher %d died from starvation.\n", i + 1);
		else
			printf("Philosopher %d went home.\n", i + 1);
	}
	
	Stats();
	
	return EXIT_SUCCESS;
}

void* Dinner(void* arg)
{
	int i, id, left, right;
	bool isCaptured;
	id = *(int*)arg;
	sem_post(&threadsQueue);
	left = id % PEOPLE_COUNT;
	right = (id - 1) % PEOPLE_COUNT;
	
	while(true)
	{
		pthread_mutex_lock(&forks[left]);
		printf("Philosopher %d took left fork.\n", id);
		isCaptured = false;
		sleep(rand() % RANDOM + 2);
		for(i = 0; i < TRIES_NUMBER; i++)
		{
			if(pthread_mutex_trylock(&forks[right]) == 0)
			{
				isCaptured = true;
				break;
			}
			else sleep(1);
		}
		if(isCaptured)
		{
			printf("Philosopher %d took right fork.\n", id);
			sleep(5);
			printf("Philosopher %d ate enough.\n", id);
			pthread_mutex_unlock(&forks[right]);
			printf("Philosopher %d put down right fork.\n", id);
			pthread_mutex_unlock(&forks[left]);
			printf("Philosopher %d put down left fork.\n", id);
			break;
		}
		else
		{
			++hunger[id - 1];
			pthread_mutex_unlock(&forks[left]);
			printf("Philosopher %d put down left fork and hates the whole world.\n", id);
			if(hunger[id - 1] == HUNGER_LEVEL) break;
			sleep(rand() % RANDOM);
		}
		sleep(3);
	}
	
	return NULL;
}

void Stats()
{
	int i;
	printf("\n");
	printf("\tStats\n");
	for(i = 0; i < PEOPLE_COUNT; i++) printf("Hunger level of philosopher %d : %d\n", i + 1, hunger[i]);	
		
	return;
}
