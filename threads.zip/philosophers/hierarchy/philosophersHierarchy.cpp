#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define PEOPLE_COUNT 5
#define BREAK_CYCLE 45
#define RANDOM 3

void* Dinner(void* arg);
void* Timer(void* arg);
void Stats();

static sem_t threadsQueue;
static sem_t timer;
static pthread_mutex_t forks[PEOPLE_COUNT] = PTHREAD_MUTEX_INITIALIZER;

int portions[PEOPLE_COUNT] = {0};
bool isEnough = false;

int main()
{
	int i, id, result;
	pthread_t philosophers[PEOPLE_COUNT];
    pthread_t timerThread;
    sem_init(&timer, 0, 0);
	sem_init(&threadsQueue, 0, 0);
	srand(times(NULL));

    pthread_create(&timerThread, NULL, &Timer, NULL);

	for(i = 0; i < PEOPLE_COUNT; i++)
	{
        id = i + 1;
		result = pthread_create(&philosophers[i], NULL, &Dinner, &id);
		if(result)
		{
			perror("Philosopher understood the meaning of life and died.\n");
			return EXIT_FAILURE;
		}
		sem_wait(&threadsQueue);
	}
	
	for(i = 0; i < PEOPLE_COUNT; i++)
	{
		result = pthread_join(philosophers[i], NULL);
		if(result)
		{
			perror("Philospher was poisoned.\n");
			return EXIT_FAILURE;
		}
		printf("Philosopher %d went away.\n", i + 1);
	}

    Stats();

	return EXIT_SUCCESS;
}

void* Dinner(void* arg)
{
	int id, first, second;
	id = *(int*)arg;
	sem_post(&threadsQueue);

	if(id % 2)
    {	
        first = (id - 1) % PEOPLE_COUNT;
	    second = id % PEOPLE_COUNT;
    }
    else
    {
        first = id % PEOPLE_COUNT;
	    second = (id - 1) % PEOPLE_COUNT;
    }

    sem_post(&timer);
    while(!isEnough)
    {
        pthread_mutex_lock(&forks[first]);
        printf("Philosopher %d took first (%d) fork.\n", id, first + 1);
        sleep(2);
        pthread_mutex_lock(&forks[second]);
        printf("Philosopher %d took second (%d) fork.\n", id, second + 1);
        sleep(4);
        ++portions[id - 1];
        printf("Philosopher %d ate %d portions.\n", id, portions[id - 1]);
        pthread_mutex_unlock(&forks[second]);
        printf("Philosopher %d put down second (%d) fork.\n", id, second + 1);
        pthread_mutex_unlock(&forks[first]);
        printf("Philosopher %d put down first (%d) fork.\n", id, first + 1);
        sleep(rand() % RANDOM + 2);
    }

	return NULL;
}

void* Timer(void* arg)
{   
    sem_wait(&timer);
    sleep(BREAK_CYCLE);
    isEnough = true;

    return NULL;
}

void Stats()
{
    int i;
    printf("\n");
    printf("\t\tStats\n");
    for(i = 0; i < PEOPLE_COUNT; i++)
        printf("Philosopher %d ate %d portions today.\n", i + 1, portions[i]);
    printf("\n");
    
    return;
}
