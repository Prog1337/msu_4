#include <unistd.h>
#include <stdio.h>

int main(void)
{
	/* определить массив с завершающим нулем команды для запуска 
	 следующим за любым параметром, в этом случае никаким */
	char *args[] = { "/bin/ls", "-l", NULL };
	
	/* fork и exec в порожденном процессе */
	if(fork() == 0)
	{
		printf("In child process:\n");
		execv(args[0], args);
		printf("I will never be called\n");
	}
	
	sleep(5);
	printf("Execution continues in parent process\n");
	
	return 0;
}
