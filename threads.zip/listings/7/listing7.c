#include <unistd.h>
#include <stdio.h>

int main(void)
{	
	if(!fork())
	{
		/* потомок немедленно завершается */
		_exit(0);
	}
	
	/* родитель ждет минуту */
	sleep(60);
	
	return 0;
}
