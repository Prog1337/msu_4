#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define DRUM 6
#define OFFICER_COUNT 4

void* RussianRoulette(void* arg);

static sem_t firstDoor, secondDoor, threadsQueue;
static pthread_mutex_t check = PTHREAD_MUTEX_INITIALIZER;

static int last = OFFICER_COUNT, alive = OFFICER_COUNT, inFirst = 0, inSecond = 0;

int main()
{
	int i, id;
	sem_init(&firstDoor, 0, 0);
	sem_init(&secondDoor, 0, 0);
	sem_init(&threadsQueue, 0, 0);
	pthread_t officers[OFFICER_COUNT];
	srand(times(NULL));
	
	for(i = 0; i < OFFICER_COUNT; i++)
	{
		id = i + 1;
		pthread_create(&officers[i], NULL, &RussianRoulette, &id);
		sem_wait(&threadsQueue);
	}
	
	for(i = 0; i < OFFICER_COUNT; i++)
		pthread_join(officers[i], NULL);
	
	return EXIT_SUCCESS;
}

void* RussianRoulette(void* arg)
{
	int i, id = *(int*)arg;
	bool isDead = false;
	sem_post(&threadsQueue);
	
	while(1)
	{
		// first room
		pthread_mutex_lock(&check);
		++inFirst;
		if(inFirst == last)
		{
			inFirst = 0;
			for(i = 0; i < alive; i++)
				sem_post(&firstDoor);
			printf("Officer %d opened the first door for %d people.\n", id, alive);			
		}
		pthread_mutex_unlock(&check);
		sem_wait(&firstDoor);		
		printf("Officer %d moved into the second room.\n", id);
		
		// second room (shooting)
		sleep(2);
		printf("Officer %d is shooting...\n", id);
		if(rand() % DRUM == 0) 
		{
			isDead = true;
			printf("Officer %d shot himself.\n", id);
		}
		
		// second room (check)
		pthread_mutex_lock(&check);
		++inSecond;
		if(isDead) --alive;
		if(alive == 1 && !isDead)
		{
			printf("Only officer %d survived.\n", id);
			break;
		}
		if(inSecond == last && alive)
		{
			inSecond = 0;
			last = alive;
			for(i = 0; i < alive; i++)
				sem_post(&secondDoor);
			printf("Officer %d opened the second door for %d people.\n", id, alive);			
		}
		if(isDead) break;
		pthread_mutex_unlock(&check);
		sem_wait(&secondDoor);
		printf("Officer %d moved into the first room.\n", id);
	}
	pthread_mutex_unlock(&check);
	
	return NULL;
}
