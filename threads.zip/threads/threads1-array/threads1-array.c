#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>

/* директива прекомпилятора расставит 3 вместо n */
#define n 3

void *thread_func(void *arg)
{
	int i;
	int loc_id = *(int*)arg;
	for(i = 0; i < 3; i++)
	{
		printf("Thread %d is running i = %d\n", loc_id, i);
		sleep(1);
	}	
	return NULL;
}

int main(void)
{
	int id[n], result, i;
	pthread_t thread[n];
	
	for(i = 0; i < n; i++)
	{
		id[i] = i + 1;
		result = pthread_create(&thread[i], NULL, thread_func, &id[i]);
		if(result != 0)
		{
			fprintf(stderr, "ERROR Creating the %d thread\n", id[i]);
			return EXIT_FAILURE;
		}
		else printf("%d thread creating\n", id[i]);
		
	}
	
	for(i = 0; i < n; i++)
	{
		result = pthread_join(thread[i], NULL);
		if(result != 0)
		{
			fprintf(stderr, "Joining the %d thread\n", id[i]);
			return EXIT_FAILURE;
		}
		else printf("%d thread joining\n", id[i]);		
	}
	
	printf("Done\n");
	
	return EXIT_SUCCESS;
}
