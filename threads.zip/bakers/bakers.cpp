#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define BNUM 3
#define ENUM 7				
#define PLACES 3

void* Bake(void* arg);
void* Eat(void* arg);
void Stats();

int buns;
int freePlaces;
int bakedBuns[BNUM];
int eatenBuns[ENUM];

static sem_t bun;
static sem_t freePlace;

int main()
{
	pthread_t baker[BNUM], eater[ENUM];
	int i, bakersID[BNUM], eatersID[ENUM], result;
	sem_init(&bun, 0, 0);
	sem_init(&freePlace, 0, PLACES);
	
	printf("\tThe Start Of The Workday\n");
	for(i = 0; i < BNUM; i++)
	{
		bakersID[i] = i + 1;
		bakedBuns[i] = 0;
		result = pthread_create(&baker[i], NULL, &Bake, &bakersID[i]);
		if(result)
		{
			perror("Baker was hit by car.\n");
			return EXIT_FAILURE;
		}
	}
	for(i = 0; i < ENUM; i++)
	{
		eatersID[i] = i + 1;
		eatenBuns[i] = 0;
		result = pthread_create(&eater[i], NULL, &Eat, &eatersID[i]);
		if(result)
		{
			perror("Eater was hit by car.\n");
			return EXIT_FAILURE;
		}
	}
	
	sleep(75);
	
	printf("\n\tThe End Of The Workday\n");
	for(i = 0; i < BNUM; i++)
	{
		result = pthread_join(baker[i], NULL);
		if(result)
		{
			printf("Baker %d died of overwork.", i + 1);
			return EXIT_FAILURE;
		}
		else printf("Baker %d went home.\n", i + 1);
	}
	for(i = 0; i < ENUM; i++)
	{
		result = pthread_join(eater[i], NULL);
		if(result)
		{
			printf("Eater %d died of overeating.", i + 1);
			return EXIT_FAILURE;
		}
		else printf("Eater %d went home.\n", i + 1);
	}
	
	Stats();
	sleep(5);
	
	sem_destroy(&bun);
	sem_destroy(&freePlace);
	
	return EXIT_SUCCESS;
}

void* Bake(void* arg)
{
	int id = *(int *)arg;
	while(true)
	{		
		if(bakedBuns[id - 1] == ENUM) break;
		++bakedBuns[id - 1];
		sem_wait(&freePlace);
		sleep(6);
		printf("Baker %d is baking %d bun...\n", id, bakedBuns[id - 1]);
		sem_post(&bun);		
	}
		
	return NULL;
}

void* Eat(void* arg)
{
	int id = *(int *)arg;
	while(true)
	{
		if(eatenBuns[id - 1] == BNUM) break;
		++eatenBuns[id - 1];
		sem_wait(&bun);	
		sleep(3);
		printf("Eater %d is eating %d bun...\n", id, eatenBuns[id - 1]);
		sem_post(&freePlace);	
	}
	
	return NULL;
}

void Stats()
{
	int i;
	printf("\n\tBaked Buns:\n");
	for(i = 0; i < BNUM; i++)
		printf("Baker %d baked %d buns.\n", i + 1, bakedBuns[i]);	
	printf("\n\tEaten Buns:\n");
	for(i = 0; i < ENUM; i++)
		printf("Eater %d ate %d buns.\n", i + 1, eatenBuns[i]);
	printf("\n\tOther:\n");
	sem_getvalue(&bun, &buns);
	sem_getvalue(&freePlace, &freePlaces);
	printf("%d buns left.\n", buns);
	printf("%d free places left.\n", freePlaces);
	
	return;
}
