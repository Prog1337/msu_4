#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define RANDOM 3
#define SOFA_PLACES 4
#define CHAIR_PLACES 6
#define CLIENT_COUNT 8

void* Client(void* arg);
void* Barber(void* arg);

static sem_t sofa, chair, armchair, exitDoor, threadsQueue;
static pthread_mutex_t haircut = PTHREAD_MUTEX_INITIALIZER;

int main()
{
	int i, id;
	sem_init(&sofa, 0, SOFA_PLACES);
	sem_init(&chair, 0, CHAIR_PLACES);
	sem_init(&armchair, 0, 0);
	sem_init(&exitDoor, 0, 0);
	pthread_t barber, clients[CLIENT_COUNT];
	srand(times(NULL));
	
	pthread_create(&barber, NULL, &Barber, NULL);
	for(i = 0; i < CLIENT_COUNT; i++)
	{
		id = i + 1;
		pthread_create(&clients[i], NULL, &Client, &id);
		sem_wait(&threadsQueue);
	}
	
	pthread_join(barber, NULL);
	for(i = 0; i < CLIENT_COUNT; i++)
		pthread_join(clients[i], NULL);
	
	return EXIT_SUCCESS;
}

void* Client(void* arg)
{
	int id;
	id = *(int*)arg;
	sem_post(&threadsQueue);
	
	sem_wait(&chair);
	printf("Client %d sat down on chair.\n", id);
	sleep(rand() % RANDOM + 1);
	
	sem_wait(&sofa);
	printf("Client %d got up from chair.\n", id);
	sem_post(&chair);
	printf("Client %d sat down on sofa.\n", id);
	sleep(rand() % RANDOM + 1);
	
	pthread_mutex_lock(&haircut);
	sem_post(&sofa);
	printf("Client %d got up from sofa.\n", id);
	sleep(rand() % RANDOM + 1);
	sem_post(&armchair);
	sem_wait(&exitDoor);
	pthread_mutex_unlock(&haircut);
	
	printf("Client %d went home.\n", id);
	
	return NULL;
}

void* Barber(void* arg)
{
	int count = 0;
	
	while(count != CLIENT_COUNT)
	{
		printf("Barber is sleeping...\n");
		sem_wait(&armchair);
		printf("Barber cut hair of %d clients.\n", ++count);
		sleep(5);
		sem_post(&exitDoor);
		sleep(rand() % RANDOM + 1);
	}
	
	printf("Barber went home.\n");
	
	return NULL;
}
