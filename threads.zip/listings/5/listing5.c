#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(void)
{
	int fd_in, fd_out;
	
	/* задали массив на 1 килобайт памяти */
	char buf[1024];
	
	/* пустой буфер; записываем "0" в buf 1024 раза */
	memset(buf, 0, 1024);
	
	fd_in = open("/tmp/infile", O_RDONLY);
	
	/* если файл не существовал, то создается с ключем "ТолькоДляЗаписи" */
	fd_out = open("/tmp/outfile", O_WRONLY|O_CREAT);
	
	/* потомок против предка значения не имеет 
	 (оба процесса выполняют цикл while, так как нет никаких проверок) */
	fork();
	
	/* читаем из файла два байта (символа) */
	while(read(fd_in, buf, 2) > 0)
	{
		/* цикл через infile */
		printf("%d: %s\n", getpid(), buf);
		
		/* написать строку */
		sprintf(buf, "%d Hello, world!\n\r", getpid());
		
		/* пишем строку в файл */
		write(fd_out, buf, strlen(buf));
		
		sleep(1);
		
		/* пустой буфер */
		memset(buf, 0, 1024);
	}
	
	sleep(10);
		
	return 0;
}

