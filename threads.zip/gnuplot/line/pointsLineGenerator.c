#include <stdio.h>
#include <math.h>

#define n 201

int main(void)
{
	FILE *fout = NULL;
	fout = fopen("pointsLine.txt", "w");
	double x[n], y[n];
	for(int i = 0; i < n; i++)
	{
		x[i] = -10 + i / 10.;
		y[i] = pow(cos(x[i]), 3) + pow(sin(x[i]), 3);
	}
	
	for(int i = 0; i < n; i++)
	{
		fprintf(fout, "%lg %lg\n", x[i], y[i]);
	}
	
	return 0;
}
